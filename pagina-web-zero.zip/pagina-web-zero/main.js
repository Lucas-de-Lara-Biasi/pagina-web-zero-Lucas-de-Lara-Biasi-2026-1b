const post_template = document.getElementById("template_post")
const posts_container = document.getElementById("posts_container")

let posts_count = 0

function createPost(post_title, post_user, post_content) {
    //CLONANDO
    let post = post_template.cloneNode(true);
    post.id = "post_" + posts_count;

    //LOCALIZANDO
    const top_bar = post.getElementsByClassName("post_top_bar")[0]
    const bottom_bar = post.getElementsByClassName("post_bottom_bar")[0]
    const content_div = post.getElementsByClassName("post_content")[0]

    //TOP BAR
    const title = top_bar.getElementsByClassName("post_title")[0]
    const buttons = top_bar.getElementsByClassName("post_buttons")[0]

    //BOTTOM BAR
    const user = bottom_bar.getElementsByClassName("post_user")[0]
    const date = bottom_bar.getElementsByClassName("post_date")[0]

    //SETUP
    title.textContent = post_title
    user.textContent = "Por: " + post_user

    //DATE SETUP
    const current_date = new Date
    date.textContent = `${current_date.toLocaleDateString()} - ${current_date.toLocaleTimeString()}`

    //POST CONTENT SETUP
    for (let definition of post_content) {
        let element = document.createElement(definition.type)
        //PARA PARAGRAFO
        if (definition.type == "p") {
            element.textContent = definition.content
        }

        //ADD CHILD
        content_div.appendChild(element)
    }

    //BEFORE
    post.style.cssText = ''
    posts_container.appendChild(post);
    posts_count++;
}

createPost("BOAS VINDAS!", "Lucas de Lara Biasi",
    [
        { type: "p", content: "Boas vindas ao meu blog de desenvolvimento de jogos!" }
    ]
)

createPost("MOTORES GRÁFICOS", "Lucas de Lara Biasi",
    [
        { type: "p", content: "Motores gráficos são uma base fundamental para o desenvolvimento de um jogo." },
        { type: "p", content: "Esses motores gráficos são utilizados para uma melhor interação entre o desenvolvedor e a máquina, sem muitas dores de cabeça." },
        { type: "p", content: "Eles possuem funções pré programadas, gráficos pré programados e outras funcionalidades que facilitam tudo." },
        { type: "p", content: "Dentre todos os motores gráficos existem:" },
        { type: "p", content: "-UNITY" },
        { type: "p", content: "-UNREAL ENGINE" },
        { type: "p", content: "-GAMEMAKER" },
        { type: "p", content: "-RPGMAKER" },
        { type: "p", content: "-GODOT" },
    ]
)

const post_buttons = document.getElementsByClassName("post_button")

for (let button of post_buttons) {
    button.addEventListener("click", () => {
        console.log("a")
        button.getElementsByTagName("p")[0].textContent++;
    })
}