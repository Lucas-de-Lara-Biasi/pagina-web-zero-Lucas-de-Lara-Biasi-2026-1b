const number_interactables = [
    "like","dislike","heart"
]

for (let tag of number_interactables) {
    let all = document.getElementsByClassName(tag)

    for (let element of all) {
        element.addEventListener("click",() => {
            number = element.getElementsByTagName("span")[0].textContent
            console.log(number)
            number = Number(number)

            number +=1
            element.getElementsByTagName("span")[0].textContent = String(number)
        })
    }
}